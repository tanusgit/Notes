Select count(BUSINESS_CATEGORY_NAME) 
where BUSINESS_CATEGORY.LIST_OF_SUBCATEGORIES = 'National Parks'
and Business.Address contains(AZ);


--select COUNT(*) from business where 
--BUSINESSCATEGORY='BCT2' and Address LIKE '%AZ%';